/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package proyecto01;

import java.util.List;

/**
 *
 * @author josel
 */
public interface interface_perros<T> {
  
    public int update (int id, String nombre, String raza, String color,String dFisica);
  
}

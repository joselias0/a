
package proyecto01;

//
//Programa       : Proyecto01.java
//Programador    : Daniel Alejandro Barrera Quezada
//Descripción    : Proyecto POO
//Fecha Creación : 26 de marzo de 2022
//Revisión       : Ninguna
//

//Clase hija que hereda de la clase padre Productos
public class Accesorios extends Productos 
{   //variable unica para la sub clase Accesorio
    private int id;
    private String nombre;
    private float precio;
    private int cantidad;
    private String tipo;
    private String tAccesorio;

    public Accesorios(int id, String nombre, float precio, int cantidad, String tipo, String tAccesorio) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
        this.tipo = tipo;
        this.tAccesorio = tAccesorio;
    }

    public Accesorios(String nombre, float precio, int cantidad, String tipo, String tAccesorio) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
        this.tipo = tipo;
        this.tAccesorio = tAccesorio;
    }
    
    
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    public Accesorios(){
       
    }
    public Accesorios(String nombre,int precio,int cantidad,String tipo){
        super();
    }
    
    //Metodo utilizado para saber la disponibilidad de productos del tipo Accesorios

    public String gettAccesorio() {
        return tAccesorio;
    }

    public void settAccesorio(String tAccesorio) {
        this.tAccesorio = tAccesorio;
    }
    
}

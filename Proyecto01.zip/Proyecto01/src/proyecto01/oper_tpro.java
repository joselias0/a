
package proyecto01;

/**
 *
 * @author josel
 */
public interface oper_tpro <T>{
    public int createw (T t);
    public int dispo (int key);
}

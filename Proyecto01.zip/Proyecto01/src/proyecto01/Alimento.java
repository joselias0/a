
package proyecto01;

//
//Programa       : Proyecto01.java
//Programador    : Daniel Alejandro Barrera Quezada
//Descripción    : Proyecto POO
//Fecha Creación : 26 de marzo de 2022
//Revisión       : Ninguna
//

//Clase hija que hereda de la clase padre Productos
public class Alimento extends Productos 
{   //variable unica para la sub clase Higiene
    private int id;
    private String nombre;
    private float precio;
    private int cantidad;
    private String tipo;
    private String caducidad;

    public Alimento() {
    }

    public Alimento(String nombre, float precio, int cantidad, String tipo, String caducidad) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
        this.tipo = tipo;
        this.caducidad = caducidad;
    }

    public Alimento(int id, String nombre,float precio,int cantidad, String tipo, String caducidad) {
        this.nombre = nombre;
        this.precio = precio;
        this.id = id;
        this.cantidad = cantidad;
        this.tipo = tipo;
        this.caducidad = caducidad;
    }
    
    
    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public float getPrecio() {
        return precio;
    }

    @Override
    public void setPrecio(float precio) {
        this.precio = precio;
    }

    @Override
    public int getId() {
        return id;
    }

    @Override
    public void setId(int id) {
        this.id = id;
    }

    @Override
    public int getCantidad() {
        return cantidad;
    }

    @Override
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    @Override
    public String getTipo() {
        return tipo;
    }

    @Override
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    
    //Metodo utilizado para saber la disponibilidad de productos Alimenticios

    
    public String getCaducidad() {
        return caducidad;
    }

    public void setCaducidad(String caducidad) {
        this.caducidad = caducidad;
    }
    
    
    
}


package proyecto01;

//
//Programa       : Proyecto01.java
//Programador    : José Elías Morales Contreras
//Descripción    : Proyecto POO
//Fecha Creación : 26 de marzo de 2022
//Revisión       : Ninguna
//

//Clase hija que hereda de la clase padre Productos
public class Higiene extends Productos 
{   //variable unica para la sub clase Higiene
    private int id;
    private String nombre;
    private float precio;
    private int cantidad;
    private String tipo;
    private float litros;
   
    
    
    //Metodo utilizado para saber la disponibilidad de productos de Higiene

    public Higiene(int id, String nombre, float precio, int cantidad, String tipo, float litros) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
        this.tipo = tipo;
        this.litros = litros;
    }

    public Higiene(String nombre, float precio, int cantidad, String tipo, float litros) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
        this.tipo = tipo;
        this.litros = litros;
    }

    public Higiene() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public float getLitros() {
        return litros;
    }

    public void setLitros(float litros) {
        this.litros = litros;
    }

   
    
    
    

    
    
    
}
